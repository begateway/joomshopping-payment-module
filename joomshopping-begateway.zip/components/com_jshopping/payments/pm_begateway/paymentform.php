<?php
/**
 * @version      1.00
 * @author       eComCharge Ltd SIA
 * @package      pm_begateway
 * @copyright    Copyright (C) 2014
 * @license      GNU/GPL
 */
defined('_JEXEC') or die('Restricted access');
?>
<script type="text/javascript">
function check_pm_begateway(){
  jQuery('#payment_form').submit();
}
</script>
