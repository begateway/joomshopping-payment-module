## Changelog

### 2.2.1

  * Refactor `Money` to handle amount and cents independently when a
    currency set

### 2.2.0

  * Rename ``GetPaymentPageToken`` class to ``GetPaymentToken``
