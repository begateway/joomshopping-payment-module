<?php
namespace BeGateway\PaymentMethod;

class CreditCardHalva extends Base {
  public function getName() {
    return 'halva';
  }
}
?>
